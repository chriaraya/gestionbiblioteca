package dao;

import java.sql.SQLException;
import java.util.List;

public interface ICRUD<T> {
    boolean agregar(T elemento) throws SQLException;

    List<T> obtenerTodos() throws SQLException;

    boolean actualizar(T elemento) throws SQLException;

    boolean eliminar(int id) throws SQLException;
}
