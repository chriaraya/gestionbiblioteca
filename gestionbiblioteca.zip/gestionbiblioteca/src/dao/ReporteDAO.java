package dao;

import util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ReporteDAO {
    public List<Object[]> obtenerLibrosMasPrestados() throws SQLException {
        List<Object[]> filas = new ArrayList<>();
        String sql = "SELECT l.titulo, l.autor, COUNT(p.id) AS total_prestamos "
                + "FROM prestamos p JOIN libros l ON p.id_libro = l.id "
                + "GROUP BY l.id, l.titulo, l.autor ORDER BY total_prestamos DESC";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                filas.add(new Object[]{rs.getString("titulo"), rs.getString("autor"),
                        rs.getInt("total_prestamos")});
            }
        }
        return filas;
    }

    public List<Object[]> obtenerHistorialPorEstudiante(String rutEstudiante) throws SQLException {
        List<Object[]> filas = new ArrayList<>();
        String sql = "SELECT e.nombre AS estudiante, l.titulo AS libro, p.fecha_prestamo, "
                + "p.fecha_devolucion, p.devuelto FROM prestamos p "
                + "JOIN estudiantes e ON p.id_estudiante = e.id "
                + "JOIN libros l ON p.id_libro = l.id "
                + "WHERE REGEXP_REPLACE(UPPER(e.rut), '[^0-9K]', '') = ? "
                + "ORDER BY p.fecha_prestamo DESC";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            String rutNormalizado = rutEstudiante.replaceAll("[^0-9Kk]", "").toUpperCase();
            stmt.setString(1, rutNormalizado);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    java.sql.Date fechaDevolucion = rs.getDate("fecha_devolucion");
                    filas.add(new Object[]{rs.getString("estudiante"), rs.getString("libro"),
                            rs.getDate("fecha_prestamo"),
                            fechaDevolucion == null ? "Pendiente" : fechaDevolucion,
                            rs.getInt("devuelto") == 1 ? "Sí" : "No"});
                }
            }
        }
        return filas;
    }
}
