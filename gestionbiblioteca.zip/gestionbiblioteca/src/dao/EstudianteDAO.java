package dao;

import modelo.Estudiante;
import util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstudianteDAO implements ICRUD<Estudiante> {
    @Override
    public List<Estudiante> obtenerTodos() throws SQLException {
        List<Estudiante> estudiantes = new ArrayList<>();
        String sql = "SELECT id, nombre, rut, rol, curso, correo "
                + "FROM estudiantes ORDER BY nombre";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                estudiantes.add(new Estudiante(rs.getInt("id"), rs.getString("nombre"),
                        rs.getString("rut"), rs.getString("rol"), rs.getString("curso"),
                        rs.getString("correo")));
            }
        }
        return estudiantes;
    }

    @Override
    public boolean agregar(Estudiante estudiante) throws SQLException {
        String sql = "INSERT INTO estudiantes (nombre, rut, rol, curso, correo) "
                + "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, estudiante.getNombre());
            stmt.setString(2, estudiante.getRut());
            stmt.setString(3, estudiante.getRol());
            stmt.setString(4, estudiante.getCurso());
            stmt.setString(5, estudiante.getCorreo());
            return stmt.executeUpdate() == 1;
        }
    }

    @Override
    public boolean actualizar(Estudiante estudiante) throws SQLException {
        String sql = "UPDATE estudiantes SET nombre = ?, rut = ?, rol = ?, curso = ?, "
                + "correo = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, estudiante.getNombre());
            stmt.setString(2, estudiante.getRut());
            stmt.setString(3, estudiante.getRol());
            stmt.setString(4, estudiante.getCurso());
            stmt.setString(5, estudiante.getCorreo());
            stmt.setInt(6, estudiante.getId());
            return stmt.executeUpdate() == 1;
        }
    }

    @Override
    public boolean eliminar(int id) throws SQLException {
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "DELETE FROM estudiantes WHERE id = ?")) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() == 1;
        }
    }
}
