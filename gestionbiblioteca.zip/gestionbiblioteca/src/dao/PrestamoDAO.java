package dao;

import util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDAO {
    public synchronized boolean registrarPrestamoSincronizado(int idEstudiante, int idLibro)
            throws SQLException {
        try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement stmt = conn.prepareStatement(
                        "SELECT id FROM estudiantes WHERE id = ?")) {
                    stmt.setInt(1, idEstudiante);
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            return false;
                        }
                    }
                }

                try (PreparedStatement stmt = conn.prepareStatement(
                        "SELECT stock FROM libros WHERE id = ? FOR UPDATE")) {
                    stmt.setInt(1, idLibro);
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (!rs.next() || rs.getInt("stock") <= 0) {
                            conn.rollback();
                            return false;
                        }
                    }
                }

                try (PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE libros SET stock = stock - 1 WHERE id = ? AND stock > 0")) {
                    stmt.setInt(1, idLibro);
                    if (stmt.executeUpdate() != 1) {
                        conn.rollback();
                        return false;
                    }
                }

                try (PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO prestamos "
                                + "(id_estudiante, id_libro, fecha_prestamo, devuelto) "
                                + "VALUES (?, ?, SYSDATE, 0)")) {
                    stmt.setInt(1, idEstudiante);
                    stmt.setInt(2, idLibro);
                    stmt.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (SQLException ex) {
                rollback(conn, ex);
                throw ex;
            }
        }
    }

    public synchronized boolean registrarDevolucionSincronizada(int idPrestamo)
            throws SQLException {
        try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try {
                int idLibro;
                try (PreparedStatement stmt = conn.prepareStatement(
                        "SELECT id_libro FROM prestamos WHERE id = ? AND devuelto = 0 FOR UPDATE")) {
                    stmt.setInt(1, idPrestamo);
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            return false;
                        }
                        idLibro = rs.getInt("id_libro");
                    }
                }

                try (PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE prestamos SET devuelto = 1, fecha_devolucion = SYSDATE "
                                + "WHERE id = ? AND devuelto = 0")) {
                    stmt.setInt(1, idPrestamo);
                    if (stmt.executeUpdate() != 1) {
                        conn.rollback();
                        return false;
                    }
                }
                try (PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE libros SET stock = stock + 1 WHERE id = ?")) {
                    stmt.setInt(1, idLibro);
                    if (stmt.executeUpdate() != 1) {
                        throw new SQLException("No se encontró el libro asociado al préstamo.");
                    }
                }
                conn.commit();
                return true;
            } catch (SQLException ex) {
                rollback(conn, ex);
                throw ex;
            }
        }
    }

    public List<Object[]> obtenerPrestamosActivos() throws SQLException {
        List<Object[]> prestamos = new ArrayList<>();
        String sql = "SELECT p.id, e.nombre AS estudiante, l.titulo AS libro, p.fecha_prestamo "
                + "FROM prestamos p JOIN estudiantes e ON p.id_estudiante = e.id "
                + "JOIN libros l ON p.id_libro = l.id "
                + "WHERE p.devuelto = 0 ORDER BY p.id DESC";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                prestamos.add(new Object[]{rs.getInt("id"), rs.getString("estudiante"),
                        rs.getString("libro"), rs.getDate("fecha_prestamo")});
            }
        }
        return prestamos;
    }

    private static void rollback(Connection conn, SQLException original) {
        try {
            conn.rollback();
        } catch (SQLException rollbackError) {
            original.addSuppressed(rollbackError);
        }
    }
}
