package vista;

import dao.EstudianteDAO;
import dao.LibroDAO;
import dao.PrestamoDAO;
import dao.ReporteDAO;
import modelo.Estudiante;
import modelo.Libro;
import util.OracleSyncService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

public class MainFrame extends JFrame {
    private final LibroDAO libroDAO = new LibroDAO();
    private final EstudianteDAO estudianteDAO = new EstudianteDAO();
    private final PrestamoDAO prestamoDAO = new PrestamoDAO();
    private final ReporteDAO reporteDAO = new ReporteDAO();
    private final OracleSyncService syncService;

    private DefaultTableModel modelLibros;
    private JTable tableLibros;
    private DefaultTableModel modelEstudiantes;
    private DefaultTableModel modelPrestamosActivos;
    private DefaultTableModel modelReportes;
    private JTable tableEstudiantes;
    private JTable tableReportes;
    private JTabbedPane tabbedPane;
    private JTextField txtEstudianteId;
    private JTextField txtLibroId;
    private JTextField txtPrestamoIdDevolucion;
    private JProgressBar progressPrestamo;
    private JProgressBar progressDevolucion;
    private JButton btnProcesarPrestamo;
    private JButton btnProcesarDevolucion;
    private JButton btnSincronizar;
    private JLabel lblEstadoConexion;
    private boolean sincronizacionEnCurso;

    public MainFrame(String nombreUsuario, String rolUsuario) throws SQLException {
        syncService = new OracleSyncService();
        setTitle("Sistema de Gestión de Biblioteca Escolar - Usuario: "
                + nombreUsuario + " (" + rolUsuario + ")");
        setSize(950, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Gestión de Libros", crearPanelLibros());
        tabbedPane.addTab("Gestión de Estudiantes", crearPanelEstudiantes());
        tabbedPane.addTab("Préstamos y Devoluciones", crearPanelPrestamos());
        tabbedPane.addTab("Reportes", crearPanelReportes());
        add(tabbedPane);
        add(crearBarraSincronizacion(), BorderLayout.SOUTH);

        cargarLibros();
        cargarEstudiantes();
        cargarPrestamosActivos();
        Timer reintentoSincronizacion = new Timer(60_000, event -> sincronizar(false));
        reintentoSincronizacion.start();
        sincronizar(false);
    }

    private JPanel crearBarraSincronizacion() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnSincronizar = new JButton("Sincronizar con Oracle");
        lblEstadoConexion = new JLabel("Modo local: datos guardados en este equipo");
        panel.add(btnSincronizar);
        panel.add(lblEstadoConexion);
        btnSincronizar.addActionListener(event -> sincronizar(true));
        return panel;
    }

    private void sincronizar(boolean mostrarResultado) {
        if (sincronizacionEnCurso) {
            return;
        }
        sincronizacionEnCurso = true;
        btnSincronizar.setEnabled(false);
        lblEstadoConexion.setText("Conservando datos localmente; intentando Oracle...");
        new SwingWorker<OracleSyncService.SyncResult, Void>() {
            @Override
            protected OracleSyncService.SyncResult doInBackground() throws Exception {
                return syncService.syncNow();
            }

            @Override
            protected void done() {
                sincronizacionEnCurso = false;
                btnSincronizar.setEnabled(true);
                try {
                    OracleSyncService.SyncResult result = get();
                    lblEstadoConexion.setText("Oracle sincronizado: "
                            + result.students() + " usuarios, " + result.books()
                            + " libros, " + result.insertedLoans() + " préstamos nuevos, "
                            + result.updatedLoans() + " devoluciones/actualizaciones.");
                    if (mostrarResultado) {
                        JOptionPane.showMessageDialog(MainFrame.this,
                                lblEstadoConexion.getText(), "Sincronización completada",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    lblEstadoConexion.setText("Los datos siguen guardados localmente; "
                            + "sincronización interrumpida.");
                    if (mostrarResultado) {
                        mostrarError(lblEstadoConexion.getText());
                    }
                } catch (ExecutionException ex) {
                    Throwable causa = ex.getCause();
                    lblEstadoConexion.setText("Modo local activo; Oracle no disponible. "
                            + "Se reintentará automáticamente.");
                    if (mostrarResultado) {
                        mostrarError("No se perdieron datos locales. No se pudo sincronizar: "
                                + causa.getMessage());
                    } else {
                        System.err.println("Sincronización Oracle pendiente: "
                                + causa.getMessage());
                    }
                }
            }
        }.execute();
    }

    private JPanel crearPanelLibros() {
        JPanel panel = new JPanel(new BorderLayout());
        modelLibros = nonEditableModel("ID", "Título", "Autor", "ISBN",
                "Editorial", "Stock", "Categoría");
        tableLibros = new JTable(modelLibros);
        panel.add(new JScrollPane(tableLibros), BorderLayout.CENTER);

        JPanel botones = new JPanel();
        JButton btnRefrescar = new JButton("Cargar / Refrescar");
        JButton btnAgregar = new JButton("Agregar Libro");
        JButton btnEditar = new JButton("Editar Stock");
        JButton btnEliminar = new JButton("Eliminar Libro");
        JButton btnExportar = new JButton("Exportar catálogo TXT");
        botones.add(btnRefrescar);
        botones.add(btnAgregar);
        botones.add(btnEditar);
        botones.add(btnEliminar);
        botones.add(btnExportar);
        panel.add(botones, BorderLayout.SOUTH);

        btnRefrescar.addActionListener(event -> cargarLibros());
        btnAgregar.addActionListener(event -> mostrarDialogoAgregarLibro());
        btnEditar.addActionListener(event -> mostrarDialogoEditarLibro());
        btnEliminar.addActionListener(event -> eliminarLibroSeleccionado());
        btnExportar.addActionListener(event -> exportarModeloComoTxt(
                "catalogo_libros.txt", modelLibros));
        return panel;
    }

    private JPanel crearPanelEstudiantes() {
        JPanel panel = new JPanel(new BorderLayout());
        modelEstudiantes = nonEditableModel("ID", "Nombre", "RUT", "Rol", "Curso", "Correo");
        tableEstudiantes = new JTable(modelEstudiantes);
        panel.add(new JScrollPane(tableEstudiantes), BorderLayout.CENTER);

        JPanel botones = new JPanel();
        JButton btnRefrescar = new JButton("Cargar Estudiantes");
        JButton btnAgregar = new JButton("Registrar Estudiante");
        JButton btnEditar = new JButton("Editar seleccionado");
        JButton btnEliminar = new JButton("Eliminar seleccionado");
        JButton btnHistorial = new JButton("Ver historial seleccionado");
        JButton btnExportar = new JButton("Exportar usuarios TXT");
        botones.add(btnRefrescar);
        botones.add(btnAgregar);
        botones.add(btnEditar);
        botones.add(btnEliminar);
        botones.add(btnHistorial);
        botones.add(btnExportar);
        panel.add(botones, BorderLayout.SOUTH);
        btnRefrescar.addActionListener(event -> cargarEstudiantes());
        btnAgregar.addActionListener(event -> mostrarDialogoAgregarEstudiante());
        btnEditar.addActionListener(event -> editarEstudianteSeleccionado());
        btnEliminar.addActionListener(event -> eliminarEstudianteSeleccionado());
        btnHistorial.addActionListener(event -> mostrarHistorialEstudianteSeleccionado());
        btnExportar.addActionListener(event -> exportarModeloComoTxt(
                "usuarios_estudiantes.txt", modelEstudiantes));
        return panel;
    }

    private JPanel crearPanelPrestamos() {
        JPanel panel = new JPanel(new GridLayout(2, 1, 10, 10));

        JPanel solicitud = new JPanel(new GridBagLayout());
        solicitud.setBorder(BorderFactory.createTitledBorder("Registro de Préstamo"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        txtEstudianteId = new JTextField(8);
        txtLibroId = new JTextField(8);
        btnProcesarPrestamo = new JButton("Registrar Préstamo en Oracle");
        progressPrestamo = new JProgressBar();
        progressPrestamo.setStringPainted(true);

        gbc.gridx = 0;
        gbc.gridy = 0;
        solicitud.add(new JLabel("ID Estudiante:"), gbc);
        gbc.gridx = 1;
        solicitud.add(txtEstudianteId, gbc);
        gbc.gridx = 2;
        solicitud.add(new JLabel("ID Libro:"), gbc);
        gbc.gridx = 3;
        solicitud.add(txtLibroId, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 4;
        solicitud.add(btnProcesarPrestamo, gbc);
        gbc.gridy = 2;
        solicitud.add(progressPrestamo, gbc);
        btnProcesarPrestamo.addActionListener(event -> ejecutarPrestamo());

        JPanel devolucion = new JPanel(new BorderLayout());
        devolucion.setBorder(BorderFactory.createTitledBorder("Devoluciones"));
        modelPrestamosActivos = nonEditableModel(
                "ID Préstamo", "Estudiante", "Libro", "Fecha Préstamo");
        JTable tableActivos = new JTable(modelPrestamosActivos);
        tableActivos.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && tableActivos.getSelectedRow() >= 0) {
                int fila = tableActivos.convertRowIndexToModel(tableActivos.getSelectedRow());
                txtPrestamoIdDevolucion.setText(
                        String.valueOf(modelPrestamosActivos.getValueAt(fila, 0)));
            }
        });
        devolucion.add(new JScrollPane(tableActivos), BorderLayout.CENTER);
        JPanel controles = new JPanel(new FlowLayout());
        txtPrestamoIdDevolucion = new JTextField(8);
        btnProcesarDevolucion = new JButton("Procesar Devolución");
        JButton btnExportarActivos = new JButton("Exportar préstamos TXT");
        progressDevolucion = new JProgressBar(0, 100);
        progressDevolucion.setStringPainted(true);
        controles.add(new JLabel("ID Préstamo:"));
        controles.add(txtPrestamoIdDevolucion);
        controles.add(btnProcesarDevolucion);
        controles.add(btnExportarActivos);
        controles.add(progressDevolucion);
        devolucion.add(controles, BorderLayout.SOUTH);
        btnProcesarDevolucion.addActionListener(event -> ejecutarDevolucion());
        btnExportarActivos.addActionListener(event -> exportarModeloComoTxt(
                "prestamos_activos.txt", modelPrestamosActivos));

        panel.add(solicitud);
        panel.add(devolucion);
        return panel;
    }

    private JPanel crearPanelReportes() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel controles = new JPanel(new FlowLayout());
        JButton btnMasPrestados = new JButton("Libros Más Prestados");
        JButton btnHistorial = new JButton("Historial por RUT");
        JButton btnActivos = new JButton("Préstamos Activos");
        controles.add(btnMasPrestados);
        controles.add(btnHistorial);
        controles.add(btnActivos);
        panel.add(controles, BorderLayout.NORTH);

        modelReportes = nonEditableModel();
        tableReportes = new JTable(modelReportes);
        panel.add(new JScrollPane(tableReportes), BorderLayout.CENTER);
        JButton btnExportar = new JButton("Exportar reporte TXT");
        controles.add(btnExportar);
        btnMasPrestados.addActionListener(event -> mostrarLibrosMasPrestados());
        btnHistorial.addActionListener(event -> mostrarHistorial());
        btnActivos.addActionListener(event -> mostrarActivosEnReporte());
        btnExportar.addActionListener(event ->
                exportarModeloComoTxt("reporte_biblioteca.txt", modelReportes));
        return panel;
    }

    private void cargarLibros() {
        ejecutarEnSegundoPlano(libroDAO::obtenerTodos, libros -> {
            modelLibros.setRowCount(0);
            categoryIdByBook.clear();
            for (Libro libro : libros) {
                modelLibros.addRow(new Object[]{libro.getId(), libro.getTitulo(), libro.getAutor(),
                        libro.getIsbn(), libro.getEditorial(), libro.getStock(),
                        libro.getNombreCategoria()});
                categoryIdByBook.put(libro.getId(), libro.getIdCategoria());
            }
        });
    }

    private void cargarEstudiantes() {
        ejecutarEnSegundoPlano(estudianteDAO::obtenerTodos, estudiantes -> {
            modelEstudiantes.setRowCount(0);
            for (Estudiante estudiante : estudiantes) {
                modelEstudiantes.addRow(new Object[]{estudiante.getId(), estudiante.getNombre(),
                        estudiante.getRut(), estudiante.getRol(), estudiante.getCurso(),
                        estudiante.getCorreo()});
            }
        });
    }

    private void cargarPrestamosActivos() {
        ejecutarEnSegundoPlano(prestamoDAO::obtenerPrestamosActivos, this::actualizarPrestamosActivos);
    }

    private void actualizarPrestamosActivos(List<Object[]> prestamos) {
        modelPrestamosActivos.setRowCount(0);
        for (Object[] prestamo : prestamos) {
            modelPrestamosActivos.addRow(prestamo);
        }
    }

    private void mostrarDialogoAgregarLibro() {
        JTextField titulo = new JTextField();
        JTextField autor = new JTextField();
        JTextField isbn = new JTextField();
        JTextField editorial = new JTextField();
        JTextField stock = new JTextField("0");
        JTextField categoria = new JTextField("1");
        Object[] campos = {"Título:", titulo, "Autor:", autor, "ISBN:", isbn,
                "Editorial:", editorial, "Stock inicial:", stock,
                "ID categoría:", categoria};
        if (JOptionPane.showConfirmDialog(this, campos, "Agregar libro",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }
        try {
            int cantidad = Integer.parseInt(stock.getText().trim());
            int idCategoria = Integer.parseInt(categoria.getText().trim());
            if (cantidad < 0 || idCategoria < 1 || titulo.getText().isBlank()) {
                throw new IllegalArgumentException("Completa el título y usa valores válidos.");
            }
            Libro libro = new Libro(0, titulo.getText().trim(), autor.getText().trim(),
                    isbn.getText().trim(), editorial.getText().trim(), cantidad, idCategoria);
            ejecutarEnSegundoPlano(() -> libroDAO.agregar(libro), agregado -> {
                if (agregado) {
                    JOptionPane.showMessageDialog(this, "Libro registrado.");
                    cargarLibros();
                } else {
                    mostrarError("No se pudo registrar el libro.");
                }
            });
        } catch (IllegalArgumentException ex) {
            mostrarError("Revisa el stock, la categoría y el título ingresados.");
        }
    }

    private void mostrarDialogoEditarLibro() {
        int fila = tableLibros.getSelectedRow();
        if (fila < 0) {
            mostrarError("Selecciona un libro de la tabla.");
            return;
        }
        int modelRow = tableLibros.convertRowIndexToModel(fila);
        int id = (int) modelLibros.getValueAt(modelRow, 0);
        int stockActual = (int) modelLibros.getValueAt(modelRow, 5);
        JTextField stock = new JTextField(String.valueOf(stockActual));
        if (JOptionPane.showConfirmDialog(this,
                new Object[]{"Nuevo stock:", stock}, "Editar stock",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }
        try {
            int nuevoStock = Integer.parseInt(stock.getText().trim());
            if (nuevoStock < 0) {
                throw new NumberFormatException();
            }
            Libro libro = new Libro(id, (String) modelLibros.getValueAt(modelRow, 1),
                    (String) modelLibros.getValueAt(modelRow, 2),
                    (String) modelLibros.getValueAt(modelRow, 3),
                    (String) modelLibros.getValueAt(modelRow, 4), nuevoStock,
                    categoryIdByBook.get(id));
            ejecutarEnSegundoPlano(() -> libroDAO.actualizar(libro), actualizado -> {
                if (actualizado) {
                    cargarLibros();
                } else {
                    mostrarError("El libro ya no existe.");
                }
            });
        } catch (NumberFormatException ex) {
            mostrarError("El stock debe ser un entero mayor o igual a cero.");
        }
    }

    private final java.util.Map<Integer, Integer> categoryIdByBook = new java.util.HashMap<>();

    private void eliminarLibroSeleccionado() {
        int fila = tableLibros.getSelectedRow();
        if (fila < 0) {
            mostrarError("Selecciona un libro de la tabla.");
            return;
        }
        int modelRow = tableLibros.convertRowIndexToModel(fila);
        int id = (int) modelLibros.getValueAt(modelRow, 0);
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar el libro seleccionado?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
            return;
        }
        ejecutarEnSegundoPlano(() -> libroDAO.eliminar(id), eliminado -> {
            if (eliminado) {
                cargarLibros();
            } else {
                mostrarError("No se pudo eliminar el libro.");
            }
        });
    }

    private void mostrarDialogoAgregarEstudiante() {
        JTextField nombre = new JTextField();
        JTextField rut = new JTextField();
        JTextField rol = new JTextField("Estudiante");
        JTextField curso = new JTextField();
        JTextField correo = new JTextField();
        Object[] campos = {"Nombre:", nombre, "RUT:", rut, "Rol:", rol,
                "Curso:", curso, "Correo:", correo};
        if (JOptionPane.showConfirmDialog(this, campos, "Registrar estudiante",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }
        if (nombre.getText().isBlank() || rut.getText().isBlank()) {
            mostrarError("El nombre y el RUT son obligatorios.");
            return;
        }
        Estudiante estudiante = new Estudiante(0, nombre.getText().trim(), rut.getText().trim(),
                rol.getText().trim(), curso.getText().trim(), correo.getText().trim());
        ejecutarEnSegundoPlano(() -> estudianteDAO.agregar(estudiante), agregado -> {
            if (agregado) {
                cargarEstudiantes();
            } else {
                mostrarError("No se pudo registrar al estudiante.");
            }
        });
    }

    private void editarEstudianteSeleccionado() {
        int fila = tableEstudiantes.getSelectedRow();
        if (fila < 0) {
            mostrarError("Selecciona un usuario de la lista.");
            return;
        }
        int row = tableEstudiantes.convertRowIndexToModel(fila);
        int id = (int) modelEstudiantes.getValueAt(row, 0);
        JTextField nombre = new JTextField(String.valueOf(modelEstudiantes.getValueAt(row, 1)));
        JTextField rut = new JTextField(String.valueOf(modelEstudiantes.getValueAt(row, 2)));
        JTextField rol = new JTextField(String.valueOf(modelEstudiantes.getValueAt(row, 3)));
        JTextField curso = new JTextField(String.valueOf(modelEstudiantes.getValueAt(row, 4)));
        JTextField correo = new JTextField(String.valueOf(modelEstudiantes.getValueAt(row, 5)));
        Object[] campos = {"Nombre:", nombre, "RUT:", rut, "Rol:", rol,
                "Curso:", curso, "Correo:", correo};
        if (JOptionPane.showConfirmDialog(this, campos, "Editar usuario",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }
        if (nombre.getText().isBlank() || rut.getText().isBlank() || rol.getText().isBlank()) {
            mostrarError("Nombre, RUT y rol son obligatorios.");
            return;
        }
        Estudiante estudiante = new Estudiante(id, nombre.getText().trim(), rut.getText().trim(),
                rol.getText().trim(), curso.getText().trim(), correo.getText().trim());
        ejecutarEnSegundoPlano(() -> estudianteDAO.actualizar(estudiante), actualizado -> {
            if (actualizado) {
                cargarEstudiantes();
            } else {
                mostrarError("No se encontró el usuario para actualizar.");
            }
        });
    }

    private void eliminarEstudianteSeleccionado() {
        int fila = tableEstudiantes.getSelectedRow();
        if (fila < 0) {
            mostrarError("Selecciona un usuario de la lista.");
            return;
        }
        int row = tableEstudiantes.convertRowIndexToModel(fila);
        int id = (int) modelEstudiantes.getValueAt(row, 0);
        String nombre = String.valueOf(modelEstudiantes.getValueAt(row, 1));
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar a " + nombre + "?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
            return;
        }
        ejecutarEnSegundoPlano(() -> estudianteDAO.eliminar(id), eliminado -> {
            if (eliminado) {
                cargarEstudiantes();
            } else {
                mostrarError("No se encontró el usuario para eliminar.");
            }
        });
    }

    private void mostrarHistorialEstudianteSeleccionado() {
        int fila = tableEstudiantes.getSelectedRow();
        if (fila < 0) {
            mostrarError("Selecciona un usuario para consultar su historial.");
            return;
        }
        int row = tableEstudiantes.convertRowIndexToModel(fila);
        String rut = String.valueOf(modelEstudiantes.getValueAt(row, 2));
        tabbedPane.setSelectedIndex(3);
        cargarHistorial(rut);
    }

    private void ejecutarPrestamo() {
        final int idEstudiante;
        final int idLibro;
        try {
            idEstudiante = Integer.parseInt(txtEstudianteId.getText().trim());
            idLibro = Integer.parseInt(txtLibroId.getText().trim());
            if (idEstudiante <= 0 || idLibro <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            mostrarError("Ingresa IDs enteros positivos.");
            return;
        }
        btnProcesarPrestamo.setEnabled(false);
        progressPrestamo.setIndeterminate(true);
        progressPrestamo.setString("Procesando...");
        ejecutarEnSegundoPlano(() -> prestamoDAO.registrarPrestamoSincronizado(
                idEstudiante, idLibro), exito -> {
            progressPrestamo.setIndeterminate(false);
            progressPrestamo.setString("");
            btnProcesarPrestamo.setEnabled(true);
            if (exito) {
                JOptionPane.showMessageDialog(this, "Préstamo registrado y stock actualizado.");
                txtEstudianteId.setText("");
                txtLibroId.setText("");
                cargarLibros();
                cargarPrestamosActivos();
            } else {
                mostrarError("No existe el estudiante o el libro, o no hay stock disponible.");
            }
        }, () -> {
            progressPrestamo.setIndeterminate(false);
            progressPrestamo.setString("");
            btnProcesarPrestamo.setEnabled(true);
        });
    }

    private void ejecutarDevolucion() {
        final int idPrestamo;
        try {
            idPrestamo = Integer.parseInt(txtPrestamoIdDevolucion.getText().trim());
            if (idPrestamo <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            mostrarError("Ingresa un ID de préstamo entero positivo.");
            return;
        }
        btnProcesarDevolucion.setEnabled(false);
        progressDevolucion.setIndeterminate(true);
        progressDevolucion.setString("Procesando...");
        ejecutarEnSegundoPlano(() -> prestamoDAO.registrarDevolucionSincronizada(idPrestamo),
                exito -> {
                    progressDevolucion.setIndeterminate(false);
                    progressDevolucion.setString("");
                    btnProcesarDevolucion.setEnabled(true);
                    if (exito) {
                        JOptionPane.showMessageDialog(this,
                                "Devolución registrada y stock restaurado.");
                        txtPrestamoIdDevolucion.setText("");
                        cargarLibros();
                        cargarPrestamosActivos();
                    } else {
                        mostrarError("El préstamo no existe o ya fue devuelto.");
                    }
                }, () -> {
                    progressDevolucion.setIndeterminate(false);
                    progressDevolucion.setString("");
                    btnProcesarDevolucion.setEnabled(true);
                });
    }

    private void mostrarLibrosMasPrestados() {
        ejecutarEnSegundoPlano(reporteDAO::obtenerLibrosMasPrestados,
                filas -> mostrarFilasReporte(new String[]{"Título", "Autor", "Total préstamos"}, filas));
    }

    private void mostrarHistorial() {
        String rut = JOptionPane.showInputDialog(this, "Ingresa el RUT del estudiante:");
        if (rut == null || rut.isBlank()) {
            return;
        }
        cargarHistorial(rut.trim());
    }

    private void cargarHistorial(String rut) {
        ejecutarEnSegundoPlano(() -> reporteDAO.obtenerHistorialPorEstudiante(rut.trim()),
                filas -> mostrarFilasReporte(new String[]{"Estudiante", "Libro", "Fecha préstamo",
                        "Fecha devolución", "Devuelto"}, filas));
    }

    private void mostrarActivosEnReporte() {
        ejecutarEnSegundoPlano(prestamoDAO::obtenerPrestamosActivos,
                filas -> mostrarFilasReporte(new String[]{"ID Préstamo", "Estudiante",
                        "Libro", "Fecha préstamo"}, filas));
    }

    private void mostrarFilasReporte(String[] columnas, List<Object[]> filas) {
        modelReportes.setColumnIdentifiers(columnas);
        modelReportes.setRowCount(0);
        for (Object[] fila : filas) {
            modelReportes.addRow(fila);
        }
    }

    private void exportarModeloComoTxt(String nombreSugerido, DefaultTableModel model) {
        JFileChooser selector = new JFileChooser();
        selector.setDialogTitle("Guardar información en archivo TXT");
        selector.setSelectedFile(new java.io.File(nombreSugerido));
        if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        Path destino = selector.getSelectedFile().toPath();
        if (!destino.getFileName().toString().toLowerCase().endsWith(".txt")) {
            destino = destino.resolveSibling(destino.getFileName() + ".txt");
        }

        List<String> lineas = new ArrayList<>();
        for (int columna = 0; columna < model.getColumnCount(); columna++) {
            lineas.add(limpiarCampoTxt(model.getColumnName(columna)));
        }
        String separador = String.join(" | ", lineas);
        List<String> contenido = new ArrayList<>();
        contenido.add(separador);
        contenido.add("-".repeat(Math.max(20, separador.length())));
        for (int fila = 0; fila < model.getRowCount(); fila++) {
            List<String> valores = new ArrayList<>();
            for (int columna = 0; columna < model.getColumnCount(); columna++) {
                valores.add(limpiarCampoTxt(model.getValueAt(fila, columna)));
            }
            contenido.add(String.join(" | ", valores));
        }

        Path archivoDestino = destino;
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws IOException {
                try (BufferedWriter writer = Files.newBufferedWriter(
                        archivoDestino, StandardCharsets.UTF_8)) {
                    for (String linea : contenido) {
                        writer.write(linea);
                        writer.newLine();
                    }
                }
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    JOptionPane.showMessageDialog(MainFrame.this,
                            "Archivo guardado en:\n" + archivoDestino,
                            "Exportación completada", JOptionPane.INFORMATION_MESSAGE);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    mostrarError("Se interrumpió la exportación del archivo.");
                } catch (ExecutionException ex) {
                    mostrarError("No se pudo guardar el TXT: " + ex.getCause().getMessage());
                }
            }
        }.execute();
    }

    private static String limpiarCampoTxt(Object valor) {
        if (valor == null) {
            return "";
        }
        return String.valueOf(valor).replace("\r", " ").replace("\n", " ")
                .replace("|", "/");
    }

    private <T> void ejecutarEnSegundoPlano(Callable<T> operacion, Consumer<T> alCompletar) {
        ejecutarEnSegundoPlano(operacion, alCompletar, () -> { });
    }

    private <T> void ejecutarEnSegundoPlano(Callable<T> operacion, Consumer<T> alCompletar,
                                            Runnable alFallar) {
        new SwingWorker<T, Void>() {
            @Override
            protected T doInBackground() throws Exception {
                return operacion.call();
            }

            @Override
            protected void done() {
                try {
                    alCompletar.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    alFallar.run();
                    mostrarError("Se interrumpió la operación.");
                } catch (ExecutionException ex) {
                    alFallar.run();
                    Throwable causa = ex.getCause();
                    String detalle = causa instanceof SQLException
                            ? causa.getMessage() : causa.toString();
                    mostrarError("No se pudo completar la operación: " + detalle);
                }
            }
        }.execute();
    }

    private static DefaultTableModel nonEditableModel(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
