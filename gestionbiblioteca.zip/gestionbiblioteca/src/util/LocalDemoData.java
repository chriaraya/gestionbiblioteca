package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public final class LocalDemoData {
    private LocalDemoData() {
    }

    public static void loadIfEmpty() throws SQLException {
        try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
            conn.setAutoCommit(false);
            try {
                if (isLoaded(conn) || hasUserData(conn)) {
                    conn.commit();
                    return;
                }
                List<Book> books = new ArrayList<>();
                List<Person> people = new ArrayList<>();
                List<Loan> loans = new ArrayList<>();
                readBundledData(books, people, loans);
                int categoryId = categoryId(conn);
                for (Book book : books) {
                    try (PreparedStatement stmt = conn.prepareStatement(
                            "INSERT INTO libros (titulo, autor, stock, id_categoria) "
                                    + "VALUES (?, ?, ?, ?)")) {
                        stmt.setString(1, book.title());
                        stmt.setString(2, book.author());
                        stmt.setInt(3, 10);
                        stmt.setInt(4, categoryId);
                        stmt.executeUpdate();
                    }
                }
                for (Person person : people) {
                    try (PreparedStatement stmt = conn.prepareStatement(
                            "INSERT INTO estudiantes (nombre, rut, rol) VALUES (?, ?, ?)")) {
                        stmt.setString(1, person.name());
                        stmt.setString(2, person.rut());
                        stmt.setString(3, person.role());
                        stmt.executeUpdate();
                    }
                }
                for (Loan loan : loans) {
                    int studentId = findId(conn, "estudiantes", "rut", loan.rut());
                    int bookId = findId(conn, "libros", "titulo", loan.title());
                    try (PreparedStatement update = conn.prepareStatement(
                            "UPDATE libros SET stock = stock - 1 WHERE id = ? AND stock > 0")) {
                        update.setInt(1, bookId);
                        if (update.executeUpdate() != 1) {
                            throw new SQLException("No hay stock para el libro " + loan.title());
                        }
                    }
                    try (PreparedStatement insert = conn.prepareStatement(
                            "INSERT INTO prestamos "
                                    + "(id_estudiante, id_libro, fecha_prestamo, devuelto) "
                                    + "VALUES (?, ?, CURRENT_DATE, 0)")) {
                        insert.setInt(1, studentId);
                        insert.setInt(2, bookId);
                        insert.executeUpdate();
                    }
                }
                try (PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO app_config (config_key, config_value) "
                                + "VALUES ('demo_seeded', 'true')")) {
                    stmt.executeUpdate();
                }
                conn.commit();
            } catch (SQLException | IOException | RuntimeException ex) {
                conn.rollback();
                if (ex instanceof SQLException sqlException) {
                    throw sqlException;
                }
                throw new SQLException("No se pudieron cargar los datos de muestra locales.", ex);
            }
        }
    }

    private static boolean isLoaded(Connection conn) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT config_value FROM app_config WHERE config_key = 'demo_seeded'");
             ResultSet rs = stmt.executeQuery()) {
            return rs.next();
        }
    }

    private static boolean hasUserData(Connection conn) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT COUNT(*) FROM estudiantes");
             ResultSet rs = stmt.executeQuery()) {
            rs.next();
            return rs.getInt(1) > 0;
        }
    }

    private static int categoryId(Connection conn) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT id FROM categorias WHERE nombre = 'General'");
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        throw new SQLException("No está creada la categoría local General.");
    }

    private static int findId(Connection conn, String table, String column, String value)
            throws SQLException {
        String sql = "SELECT id FROM " + table + " WHERE " + column + " = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, value);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        throw new SQLException("No se encontró el registro de muestra: " + value);
    }

    private static void readBundledData(List<Book> books, List<Person> people, List<Loan> loans)
            throws IOException, SQLException {
        InputStream resource = LocalDemoData.class.getResourceAsStream("/informacion_biblioteca.txt");
        if (resource == null) {
            throw new SQLException("Falta el recurso informacion_biblioteca.txt. "
                    + "Recarga los recursos Maven.");
        }
        String rut = null;
        boolean readingLoans = false;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(resource, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.startsWith("CATALOGO DE LIBROS")) {
                    readingLoans = false;
                } else if (trimmed.startsWith("USUARIOS Y PRESTAMOS")) {
                    readingLoans = true;
                } else if (!readingLoans && trimmed.matches("\\d+\\. .*\\| Autor: .*")) {
                    String[] parts = trimmed.substring(trimmed.indexOf(". ") + 2).split(
                            " \\| Autor: ", 2);
                    String author = parts[1].equals("No indicado") ? null : parts[1];
                    books.add(new Book(parts[0], author));
                } else if (readingLoans && trimmed.matches("\\d+\\. Nombre: .*")) {
                    String name = trimmed.substring(trimmed.indexOf(": ") + 2);
                    String rutLine = reader.readLine();
                    String countLine = reader.readLine();
                    if (rutLine == null || countLine == null) {
                        throw new SQLException("El listado de datos de muestra está incompleto.");
                    }
                    String[] identity = rutLine.trim().split(" \\| Rol: ", 2);
                    if (identity.length != 2 || !identity[0].startsWith("RUT: ")) {
                        throw new SQLException("No se pudo interpretar RUT/rol: " + rutLine);
                    }
                    rut = identity[0].substring(5).trim();
                    people.add(new Person(name, rut, identity[1].trim()));
                } else if (readingLoans && trimmed.startsWith("- ")) {
                    if (rut == null) {
                        throw new SQLException("Préstamo sin persona asociada en los datos.");
                    }
                    loans.add(new Loan(rut, trimmed.substring(2)));
                }
            }
        }
        if (books.isEmpty() || people.isEmpty() || loans.isEmpty()) {
            throw new SQLException("El listado de datos de muestra no contiene libros, usuarios "
                    + "o préstamos.");
        }
    }

    private record Book(String title, String author) { }
    private record Person(String name, String rut, String role) { }
    private record Loan(String rut, String title) { }
}
