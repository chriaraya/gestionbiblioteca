package util;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class OracleSyncService {
    private final String originId;

    public OracleSyncService() throws SQLException {
        originId = loadOriginId();
    }

    public synchronized SyncResult syncNow() throws SQLException {
        List<Book> books = loadBooks();
        List<Student> students = loadStudents();
        List<Loan> loans = loadLoans();
        Map<Integer, Integer> remoteBookIds = new HashMap<>();
        Map<Integer, Integer> activeLoansByBook = new HashMap<>();
        for (Loan loan : loans) {
            if (!loan.returned()) {
                activeLoansByBook.merge(loan.bookId(), 1, Integer::sum);
            }
        }

        try (Connection remote = DatabaseConnection.getInstance().getOracleConnection()) {
            ensureLoanOriginColumns(remote);
            remote.setAutoCommit(false);
            try {
                for (Student student : students) {
                    syncStudent(remote, student);
                }
                for (Book book : books) {
                    int categoryId = syncCategory(remote, book.category());
                    int remoteId = syncBook(remote, book,
                            activeLoansByBook.getOrDefault(book.id(), 0), categoryId);
                    remoteBookIds.put(book.id(), remoteId);
                }

                int inserted = 0;
                int updated = 0;
                for (Loan loan : loans) {
                    int studentId = findRemoteStudentId(remote, loan.rut());
                    Integer bookId = remoteBookIds.get(loan.bookId());
                    if (bookId == null) {
                        throw new SQLException("No se pudo sincronizar el libro "
                                + loan.bookTitle());
                    }
                    LoanSyncResult result = syncLoan(remote, loan, studentId, bookId);
                    if (result == LoanSyncResult.INSERTED) {
                        inserted++;
                    } else if (result == LoanSyncResult.UPDATED) {
                        updated++;
                    }
                }
                remote.commit();
                return new SyncResult(students.size(), books.size(), inserted, updated);
            } catch (SQLException ex) {
                try {
                    remote.rollback();
                } catch (SQLException rollbackError) {
                    ex.addSuppressed(rollbackError);
                }
                throw ex;
            }
        }
    }

    private String loadOriginId() throws SQLException {
        try (Connection local = DatabaseConnection.getInstance().getConnection()) {
            try (PreparedStatement stmt = local.prepareStatement(
                    "SELECT config_value FROM app_config WHERE config_key = 'installation_id'");
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString(1);
                }
            }
            String id = UUID.randomUUID().toString();
            try (PreparedStatement stmt = local.prepareStatement(
                    "INSERT INTO app_config (config_key, config_value) VALUES "
                            + "('installation_id', ?)")) {
                stmt.setString(1, id);
                stmt.executeUpdate();
            }
            return id;
        }
    }

    private List<Book> loadBooks() throws SQLException {
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT l.id, l.titulo, l.autor, l.isbn, l.editorial, l.stock, c.nombre "
                             + "FROM libros l JOIN categorias c ON c.id = l.id_categoria");
             ResultSet rs = stmt.executeQuery()) {
            java.util.ArrayList<Book> result = new java.util.ArrayList<>();
            while (rs.next()) {
                result.add(new Book(rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getInt(6), rs.getString(7)));
            }
            return result;
        }
    }

    private List<Student> loadStudents() throws SQLException {
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT id, nombre, rut, rol, curso, correo FROM estudiantes");
             ResultSet rs = stmt.executeQuery()) {
            java.util.ArrayList<Student> result = new java.util.ArrayList<>();
            while (rs.next()) {
                result.add(new Student(rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6)));
            }
            return result;
        }
    }

    private List<Loan> loadLoans() throws SQLException {
        String sql = "SELECT p.id, p.id_estudiante, e.rut, p.id_libro, l.titulo, "
                + "p.fecha_prestamo, p.fecha_devolucion, p.devuelto "
                + "FROM prestamos p JOIN estudiantes e ON e.id = p.id_estudiante "
                + "JOIN libros l ON l.id = p.id_libro";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            java.util.ArrayList<Loan> result = new java.util.ArrayList<>();
            while (rs.next()) {
                result.add(new Loan(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4),
                        rs.getString(5), rs.getDate(6), rs.getDate(7), rs.getInt(8) == 1));
            }
            return result;
        }
    }

    private void ensureLoanOriginColumns(Connection conn) throws SQLException {
        DatabaseMetaData metadata = conn.getMetaData();
        if (!columnExists(metadata, "PRESTAMOS", "ORIGEN_ID")) {
            try (PreparedStatement stmt = conn.prepareStatement(
                    "ALTER TABLE prestamos ADD (origen_id VARCHAR2(36))")) {
                stmt.executeUpdate();
            }
        }
        if (!columnExists(metadata, "PRESTAMOS", "ID_LOCAL")) {
            try (PreparedStatement stmt = conn.prepareStatement(
                    "ALTER TABLE prestamos ADD (id_local NUMBER(10))")) {
                stmt.executeUpdate();
            }
        }
        if (!indexExists(metadata, "UX_PRESTAMOS_ORIGEN_LOCAL")) {
            try (PreparedStatement stmt = conn.prepareStatement(
                    "CREATE UNIQUE INDEX ux_prestamos_origen_local "
                            + "ON prestamos (origen_id, id_local)")) {
                stmt.executeUpdate();
            }
        }
    }

    private static boolean columnExists(DatabaseMetaData metadata, String table, String column)
            throws SQLException {
        try (ResultSet rs = metadata.getColumns(null, null, table, column)) {
            if (rs.next()) {
                return true;
            }
        }
        try (ResultSet rs = metadata.getColumns(null, null, table.toLowerCase(),
                column.toLowerCase())) {
            return rs.next();
        }
    }

    private static boolean indexExists(DatabaseMetaData metadata, String index) throws SQLException {
        try (ResultSet rs = metadata.getIndexInfo(null, null, "PRESTAMOS", false, false)) {
            while (rs.next()) {
                if (index.equalsIgnoreCase(rs.getString("INDEX_NAME"))) {
                    return true;
                }
            }
        }
        try (ResultSet rs = metadata.getIndexInfo(null, null, "prestamos", false, false)) {
            while (rs.next()) {
                if (index.equalsIgnoreCase(rs.getString("INDEX_NAME"))) {
                    return true;
                }
            }
        }
        return false;
    }

    private int syncCategory(Connection remote, String name) throws SQLException {
        String category = name == null || name.isBlank() ? "General" : name;
        try (PreparedStatement stmt = remote.prepareStatement(
                "MERGE INTO categorias d USING (SELECT ? nombre FROM dual) s "
                        + "ON (d.nombre = s.nombre) "
                        + "WHEN NOT MATCHED THEN INSERT (nombre) VALUES (s.nombre)")) {
            stmt.setString(1, category);
            stmt.executeUpdate();
        }
        try (PreparedStatement stmt = remote.prepareStatement(
                "SELECT id FROM categorias WHERE nombre = ?")) {
            stmt.setString(1, category);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        throw new SQLException("No se pudo obtener la categoría Oracle " + category);
    }

    private int syncBook(Connection remote, Book book, int activeLoans, int categoryId)
            throws SQLException {
        Integer id = findRemoteBookId(remote, book.title());
        if (id == null) {
            String sql = "INSERT INTO libros (titulo, autor, isbn, editorial, stock, id_categoria) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = remote.prepareStatement(sql)) {
                stmt.setString(1, book.title());
                stmt.setString(2, book.author());
                stmt.setString(3, book.isbn());
                stmt.setString(4, book.publisher());
                stmt.setInt(5, book.stock() + activeLoans);
                stmt.setInt(6, categoryId);
                stmt.executeUpdate();
            }
            id = findRemoteBookId(remote, book.title());
            if (id == null) {
                throw new SQLException("No se pudo crear el libro Oracle " + book.title());
            }
        } else {
            try (PreparedStatement stmt = remote.prepareStatement(
                    "UPDATE libros SET autor = NVL(?, autor), isbn = NVL(?, isbn), "
                            + "editorial = NVL(?, editorial), id_categoria = ? WHERE id = ?")) {
                stmt.setString(1, book.author());
                stmt.setString(2, book.isbn());
                stmt.setString(3, book.publisher());
                stmt.setInt(4, categoryId);
                stmt.setInt(5, id);
                stmt.executeUpdate();
            }
        }
        return id;
    }

    private Integer findRemoteBookId(Connection conn, String title) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT id FROM libros WHERE titulo = ? ORDER BY id FETCH FIRST 1 ROWS ONLY")) {
            stmt.setString(1, title);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? rs.getInt(1) : null;
            }
        }
    }

    private void syncStudent(Connection remote, Student student) throws SQLException {
        String sql = "MERGE INTO estudiantes d USING "
                + "(SELECT ? nombre, ? rut, ? rol, ? curso, ? correo FROM dual) s "
                + "ON (REGEXP_REPLACE(UPPER(d.rut), '[^0-9K]', '') = "
                + "REGEXP_REPLACE(UPPER(s.rut), '[^0-9K]', '')) "
                + "WHEN MATCHED THEN UPDATE SET d.nombre=s.nombre, d.rol=s.rol, "
                + "d.curso=s.curso, d.correo=s.correo "
                + "WHEN NOT MATCHED THEN INSERT (nombre,rut,rol,curso,correo) "
                + "VALUES (s.nombre, REGEXP_REPLACE(UPPER(s.rut), '[^0-9K]', ''), "
                + "s.rol,s.curso,s.correo)";
        try (PreparedStatement stmt = remote.prepareStatement(sql)) {
            stmt.setString(1, student.name());
            stmt.setString(2, student.rut());
            stmt.setString(3, student.role());
            stmt.setString(4, student.course());
            stmt.setString(5, student.email());
            stmt.executeUpdate();
        }
    }

    private int findRemoteStudentId(Connection remote, String rut) throws SQLException {
        try (PreparedStatement stmt = remote.prepareStatement(
                "SELECT id FROM estudiantes WHERE "
                        + "REGEXP_REPLACE(UPPER(rut), '[^0-9K]', '') = ? "
                        + "ORDER BY id FETCH FIRST 1 ROWS ONLY")) {
            stmt.setString(1, rut.replaceAll("[^0-9Kk]", "").toUpperCase());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        throw new SQLException("No se encontró en Oracle el RUT " + rut);
    }

    private LoanSyncResult syncLoan(Connection remote, Loan loan, int studentId, int bookId)
            throws SQLException {
        boolean remoteReturned;
        try (PreparedStatement stmt = remote.prepareStatement(
                "SELECT devuelto FROM prestamos WHERE origen_id = ? AND id_local = ? FOR UPDATE")) {
            stmt.setString(1, originId);
            stmt.setInt(2, loan.id());
            try (ResultSet rs = stmt.executeQuery()) {
                if (!rs.next()) {
                    if (!loan.returned()) {
                        updateRemoteStock(remote, bookId, -1);
                    }
                    insertRemoteLoan(remote, loan, studentId, bookId);
                    return LoanSyncResult.INSERTED;
                }
                remoteReturned = rs.getInt(1) == 1;
            }
        }
        if (remoteReturned == loan.returned()) {
            return LoanSyncResult.UNCHANGED;
        }
        updateRemoteStock(remote, bookId, loan.returned() ? 1 : -1);
        try (PreparedStatement stmt = remote.prepareStatement(
                "UPDATE prestamos SET devuelto = ?, fecha_devolucion = ? "
                        + "WHERE origen_id = ? AND id_local = ?")) {
            stmt.setInt(1, loan.returned() ? 1 : 0);
            stmt.setDate(2, loan.returned() ? loan.returnDate() : null);
            stmt.setString(3, originId);
            stmt.setInt(4, loan.id());
            stmt.executeUpdate();
        }
        return LoanSyncResult.UPDATED;
    }

    private void insertRemoteLoan(Connection remote, Loan loan, int studentId, int bookId)
            throws SQLException {
        String sql = "INSERT INTO prestamos "
                + "(id_estudiante,id_libro,fecha_prestamo,fecha_devolucion,devuelto,origen_id,id_local) "
                + "VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement stmt = remote.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, bookId);
            stmt.setDate(3, loan.loanDate());
            stmt.setDate(4, loan.returnDate());
            stmt.setInt(5, loan.returned() ? 1 : 0);
            stmt.setString(6, originId);
            stmt.setInt(7, loan.id());
            stmt.executeUpdate();
        }
    }

    private void updateRemoteStock(Connection remote, int bookId, int delta) throws SQLException {
        String sql = delta < 0
                ? "UPDATE libros SET stock = stock - 1 WHERE id = ? AND stock > 0"
                : "UPDATE libros SET stock = stock + 1 WHERE id = ?";
        try (PreparedStatement stmt = remote.prepareStatement(sql)) {
            stmt.setInt(1, bookId);
            if (stmt.executeUpdate() != 1) {
                throw new SQLException("Conflicto de stock en Oracle para libro ID " + bookId
                        + "; sincronización cancelada para evitar existencias negativas.");
            }
        }
    }

    public record SyncResult(int students, int books, int insertedLoans, int updatedLoans) { }
    private record Book(int id, String title, String author, String isbn,
                        String publisher, int stock, String category) { }
    private record Student(int id, String name, String rut, String role,
                           String course, String email) { }
    private record Loan(int id, int studentId, String rut, int bookId, String bookTitle,
                        Date loanDate, Date returnDate, boolean returned) { }
    private enum LoanSyncResult { INSERTED, UPDATED, UNCHANGED }
}
