package modelo;

public abstract class Persona {
    private final int id;
    private final String nombre;

    protected Persona(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public abstract String getTipoPerfil();
}
