package modelo;

import java.sql.Date;

public class Prestamo {
    private final int id;
    private final int idEstudiante;
    private final int idLibro;
    private final Date fechaPrestamo;
    private final Date fechaDevolucion;
    private final boolean devuelto;

    public Prestamo(int id, int idEstudiante, int idLibro, Date fechaPrestamo,
                    Date fechaDevolucion, boolean devuelto) {
        this.id = id;
        this.idEstudiante = idEstudiante;
        this.idLibro = idLibro;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
        this.devuelto = devuelto;
    }

    public int getId() { return id; }
    public int getIdEstudiante() { return idEstudiante; }
    public int getIdLibro() { return idLibro; }
    public Date getFechaPrestamo() { return fechaPrestamo; }
    public Date getFechaDevolucion() { return fechaDevolucion; }
    public boolean isDevuelto() { return devuelto; }
}
