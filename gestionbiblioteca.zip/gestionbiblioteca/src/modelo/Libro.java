package modelo;

public class Libro {
    private final int id;
    private final String titulo;
    private final String autor;
    private final String isbn;
    private final String editorial;
    private final int stock;
    private final int idCategoria;
    private final String nombreCategoria;

    public Libro(int id, String titulo, String autor, String isbn, String editorial,
                 int stock, int idCategoria) {
        this(id, titulo, autor, isbn, editorial, stock, idCategoria, "");
    }

    public Libro(int id, String titulo, String autor, String isbn, String editorial,
                 int stock, int idCategoria, String nombreCategoria) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.editorial = editorial;
        this.stock = stock;
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public String getIsbn() { return isbn; }
    public String getEditorial() { return editorial; }
    public int getStock() { return stock; }
    public int getIdCategoria() { return idCategoria; }
    public String getNombreCategoria() { return nombreCategoria; }
}
