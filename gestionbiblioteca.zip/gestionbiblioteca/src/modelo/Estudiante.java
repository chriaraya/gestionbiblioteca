package modelo;

public class Estudiante extends Persona {
    private final String rut;
    private final String rol;
    private final String curso;
    private final String correo;

    public Estudiante(int id, String nombre, String rut, String curso, String correo) {
        this(id, nombre, rut, "Estudiante", curso, correo);
    }

    public Estudiante(int id, String nombre, String rut, String rol,
                      String curso, String correo) {
        super(id, nombre);
        this.rut = rut;
        this.rol = rol;
        this.curso = curso;
        this.correo = correo;
    }

    public String getRut() { return rut; }
    public String getRol() { return rol; }
    public String getCurso() { return curso; }
    public String getCorreo() { return correo; }

    @Override
    public String getTipoPerfil() {
        return rol;
    }
}
