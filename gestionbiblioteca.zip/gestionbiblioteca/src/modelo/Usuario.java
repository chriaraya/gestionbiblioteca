package modelo;

public class Usuario extends Persona {
    private final String rol;

    public Usuario(int id, String nombre, String rol) {
        super(id, nombre);
        this.rol = rol;
    }

    public String getRol() { return rol; }

    @Override
    public String getTipoPerfil() {
        return "USUARIO";
    }
}
