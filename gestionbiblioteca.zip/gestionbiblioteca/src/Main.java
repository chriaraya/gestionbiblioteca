import vista.MainFrame;
import util.DatabaseConnection;
import util.LocalDemoData;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                DatabaseConnection.getInstance().initializeLocalDatabase();
                LocalDemoData.loadIfEmpty();
                MainFrame ventanaPrincipal = new MainFrame("Ana Salas", "BIBLIOTECARIO");
                ventanaPrincipal.setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace(System.err);
                JOptionPane.showMessageDialog(null,
                        "No se pudo iniciar la aplicación.\n"
                                + ex.getClass().getSimpleName() + ": " + ex.getMessage()
                                + "\n\nRevisa que la carpeta de datos local tenga permisos "
                                + "de escritura y que no haya otra instancia bloqueándola.",
                        "Error de inicio", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
