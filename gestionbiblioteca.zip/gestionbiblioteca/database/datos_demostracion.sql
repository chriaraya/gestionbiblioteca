-- Importa personas, libros y préstamos activos del listado entregado.
-- Los RUT se guardan normalizados (sin puntos ni guion). Como el listado no
-- contiene fechas, los préstamos se registran con SYSDATE y quedan activos.
-- Es seguro volver a ejecutar este script: no duplica personas, libros ni
-- préstamos que ya estén activos para la misma persona y el mismo libro.

MERGE INTO categorias destino
USING (SELECT 'General' nombre FROM dual) origen
ON (destino.nombre = origen.nombre)
WHEN NOT MATCHED THEN
    INSERT (nombre) VALUES (origen.nombre);

MERGE INTO libros destino
USING (
    SELECT 'Final Fantasy Ultimania Archive' titulo, NULL autor FROM dual
    UNION ALL SELECT 'Clean Code Collection', 'Robert C. Martin' FROM dual
    UNION ALL SELECT 'Automate The Boring Stuff with Python', 'Al Sweigart' FROM dual
    UNION ALL SELECT 'Sombras de Raccoon City', NULL FROM dual
    UNION ALL SELECT 'Tecnología Digital Para Docentes. Computación y TIC', 'Equipo Users' FROM dual
    UNION ALL SELECT 'Introducción a la Informática y al Uso y Manejo de Aplicaciones Comerciales', 'Ana M.ª Villar Varela' FROM dual
    UNION ALL SELECT 'Visual Studio 2010. Una Nueva Forma de Desarrollo', 'Cristian Sánchez' FROM dual
    UNION ALL SELECT 'A Philosophy of Software Design', 'John Ousterhout' FROM dual
    UNION ALL SELECT 'Programación Orientada a Objetos con Java usando BlueJ', 'David J. Barnes & Michael Kölling' FROM dual
    UNION ALL SELECT 'Power and Prediction: The Disruptive Economics of Artificial Intelligence', NULL FROM dual
    UNION ALL SELECT 'Aproximación a la Ingeniería del Software', 'Sebastián Rubén Gómez Palomo & Eduardo Antonio Moraleda Gil' FROM dual
    UNION ALL SELECT 'Computer Science: An Overview - 12th Global Edition', 'J. Glenn Brookshear' FROM dual
    UNION ALL SELECT 'Ingeniería de Software: Un Enfoque Práctico', 'Roger S. Pressman / Ian Sommerville' FROM dual
    UNION ALL SELECT 'Erase Una Vez Un Algoritmo. Como Las Historias Explican La Computación', 'Martin Erwig' FROM dual
    UNION ALL SELECT 'Arquitectura Limpia', 'Robert C. Martin' FROM dual
    UNION ALL SELECT 'Nier: Automata World Guide', NULL FROM dual
    UNION ALL SELECT 'Python y Computación Paralela', 'Ricardo J. Barrientos' FROM dual
    UNION ALL SELECT 'Estructuras de Datos en Java - 4ª Ed.', 'Mark Allen Weiss' FROM dual
    UNION ALL SELECT 'El Imperio de la IA', NULL FROM dual
    UNION ALL SELECT 'Los Trucos de iPhone que Apple Nunca Te Contará', NULL FROM dual
    UNION ALL SELECT 'Computación al Minuto', 'Aguilar' FROM dual
    UNION ALL SELECT 'Análisis y Diseño de Sistemas', 'Kenneth E. Kendall & Julie E. Kendall' FROM dual
    UNION ALL SELECT 'Structure and Interpretation of Computer Programs - SICP', 'Harold Abelson & Gerald Jay Sussman' FROM dual
    UNION ALL SELECT 'Head First C', 'David Griffiths & Dawn Griffiths' FROM dual
    UNION ALL SELECT 'Testeo y Verificación de Equipos y Periféricos Microinformáticos', 'Antonio Luis Cardador Cabello' FROM dual
    UNION ALL SELECT 'Instalación y Configuración de Periféricos Microinformáticos', NULL FROM dual
) origen
ON (destino.titulo = origen.titulo)
WHEN MATCHED THEN UPDATE SET destino.autor = NVL(origen.autor, destino.autor)
WHEN NOT MATCHED THEN
    INSERT (titulo, autor, isbn, editorial, stock, id_categoria)
    VALUES (origen.titulo, origen.autor, NULL, NULL, 10,
            (SELECT id FROM categorias WHERE nombre = 'General'));

MERGE INTO estudiantes destino
USING (
    SELECT 'EITHEL KLAUSS PATRICIO GONZALEZ ROJAS' nombre, '185001017' rut, 'Profesor' rol FROM dual
    UNION ALL SELECT 'Jessica Rebolledo', '18501657K', 'Profesor' FROM dual
    UNION ALL SELECT 'ALBERTO FERMIN CAMPOS VIDAL', '185038832', 'Profesor Asistente' FROM dual
    UNION ALL SELECT 'Manuel Abarca', '185055540', 'Desarrollador del curso' FROM dual
    UNION ALL SELECT 'Matias Fernandez Z.', '185088872', 'Desarrollador del curso' FROM dual
    UNION ALL SELECT 'Guido Fuentealba', '185117155', 'Desarrollador del curso' FROM dual
    UNION ALL SELECT 'Javier Oliver C.', '185131980', 'Desarrollador del curso' FROM dual
    UNION ALL SELECT 'Bayron Pacheco B.', '18516367K', 'Desarrollador del curso' FROM dual
    UNION ALL SELECT 'Roberto Ignacio Sanchez Alvarado', '185196993', 'Desarrollador del curso' FROM dual
    UNION ALL SELECT 'Docente bsolutions', '185219381', 'Facilitador' FROM dual
    UNION ALL SELECT 'Facilitador Online', '18523691K', 'Facilitador' FROM dual
    UNION ALL SELECT 'ANDRES ACUNA ACUNA', '185254276', 'Estudiante' FROM dual
    UNION ALL SELECT 'CHRISTOPHER JOSEPH ARAYA CRUZ', '185279058', 'Estudiante' FROM dual
    UNION ALL SELECT 'ALEXANDER ARAYA VILLALOBOS', '18530561K', 'Estudiante' FROM dual
    UNION ALL SELECT 'MAXIMILIANO ENRIQUE BRIONES AGUILERA', '18533069K', 'Estudiante' FROM dual
    UNION ALL SELECT 'ANTONIA PAZ BUSTOS LOYOLA', '185360505', 'Estudiante' FROM dual
    UNION ALL SELECT 'IGNACIO ESTEBAN CARVACHO FAUNDEZ', '185394116', 'Estudiante' FROM dual
    UNION ALL SELECT 'JEREMY DANIEL CATALAN BOISIER', '185419925', 'Estudiante' FROM dual
    UNION ALL SELECT 'JOSE TOMAS CORNEJO CARDENAS', '185432794', 'Estudiante' FROM dual
    UNION ALL SELECT 'FABRIZIO ESTEBAN FERNANDINI ONATE', '185447058', 'Estudiante' FROM dual
    UNION ALL SELECT 'GABRIEL ALEJANDRO GOMEZ PIZARRO', '18547361K', 'Estudiante' FROM dual
    UNION ALL SELECT 'RODOLFO ANDRES JARAMILLO PEZOA', '185499554', 'Estudiante' FROM dual
    UNION ALL SELECT 'MAGDALENA PAZ LEITON VALDES', '185525105', 'Estudiante' FROM dual
    UNION ALL SELECT 'MATIAS FELIPE LOPEZ VILLARROEL', '185547036', 'Estudiante' FROM dual
    UNION ALL SELECT 'SANDRA MARIANA MAMANI MAMANI', '185565034', 'Estudiante' FROM dual
    UNION ALL SELECT 'CAMILO ESTEBAN MARIN PEREZ', '185594964', 'Estudiante' FROM dual
    UNION ALL SELECT 'CRISTOFER ANDRES MEDEL SEPULVEDA', '18562877K', 'Estudiante' FROM dual
    UNION ALL SELECT 'IGNACIO SEBASTIAN MELLADO RIQUELME', '185653057', 'Estudiante' FROM dual
    UNION ALL SELECT 'VICENTE ANTONIO MILLA ESPINOZA', '185665365', 'Estudiante' FROM dual
    UNION ALL SELECT 'JAVIER ANDRES MORAGA ROJAS', '185679072', 'Estudiante' FROM dual
    UNION ALL SELECT 'CLAUDIA ANDREA MUNOZ ROJAS', '185702953', 'Estudiante' FROM dual
    UNION ALL SELECT 'BENJAMIN IGNACIO NORAMBUENA OYANEDEL', '185734391', 'Estudiante' FROM dual
    UNION ALL SELECT 'EMILIO ANDRES NUNEZ JARA', '185751245', 'Estudiante' FROM dual
    UNION ALL SELECT 'NICOLAS OLIVARES MENARES', '185785239', 'Estudiante' FROM dual
    UNION ALL SELECT 'NICOLE DE JESUS ORTEGA ROMERO', '185813771', 'Estudiante' FROM dual
    UNION ALL SELECT 'ARIEL EMANUEL RAMIREZ MARDONES', '185830439', 'Estudiante' FROM dual
    UNION ALL SELECT 'JAVIER IGNACIO RUIZ ARRIAGADA', '185843352', 'Estudiante' FROM dual
    UNION ALL SELECT 'IGNACIO ANDRES SANDOVAL SANCHEZ', '185860907', 'Estudiante' FROM dual
    UNION ALL SELECT 'JAIME ANIBAL SEGUEL RETAMALES', '18588766K', 'Estudiante' FROM dual
    UNION ALL SELECT 'VICENTE SEPULVEDA SUAZO', '185920330', 'Estudiante' FROM dual
    UNION ALL SELECT 'PABLO ROBERTO SMITH ORTIZ', '185936024', 'Estudiante' FROM dual
    UNION ALL SELECT 'NICOLAS ANTONIO VALDES ROJAS', '185960952', 'Estudiante' FROM dual
    UNION ALL SELECT 'GUSTAVO IGNACIO VALENCIA MUNOZ', '185989756', 'Estudiante' FROM dual
    UNION ALL SELECT 'ANDRES PAOLO VALENZUELA ABARCA', '18600088K', 'Estudiante' FROM dual
    UNION ALL SELECT 'MAURICIO VALENZUELA FUENTES', '18601919K', 'Estudiante' FROM dual
    UNION ALL SELECT 'FRANCISCO JAVIER VILLA DURAN', '186050984', 'Estudiante' FROM dual
    UNION ALL SELECT 'GUSTAVO SAMUEL ZAPATA COVARRUBIAS', '18606859K', 'Estudiante' FROM dual
) origen
ON (REGEXP_REPLACE(UPPER(destino.rut), '[^0-9K]', '') = origen.rut)
WHEN MATCHED THEN UPDATE SET
    destino.nombre = origen.nombre,
    destino.rol = origen.rol
WHEN NOT MATCHED THEN
    INSERT (nombre, rut, rol, curso, correo)
    VALUES (origen.nombre, origen.rut, origen.rol, NULL, NULL);

DECLARE
    prestamos_existentes NUMBER;
BEGIN
    FOR asignacion IN (
        SELECT persona.rut, libro.titulo
        FROM (
            SELECT '185001017' rut, 'Final Fantasy Ultimania Archive' titulo FROM dual
            UNION ALL SELECT '18501657K', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '185038832', 'Automate The Boring Stuff with Python' FROM dual
            UNION ALL SELECT '185038832', 'Sombras de Raccoon City' FROM dual
            UNION ALL SELECT '185038832', 'Final Fantasy Ultimania Archive' FROM dual
            UNION ALL SELECT '185055540', 'Tecnología Digital Para Docentes. Computación y TIC' FROM dual
            UNION ALL SELECT '185088872', 'Introducción a la Informática y al Uso y Manejo de Aplicaciones Comerciales' FROM dual
            UNION ALL SELECT '185117155', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '185131980', 'Introducción a la Informática y al Uso y Manejo de Aplicaciones Comerciales' FROM dual
            UNION ALL SELECT '185131980', 'Visual Studio 2010. Una Nueva Forma de Desarrollo' FROM dual
            UNION ALL SELECT '185131980', 'A Philosophy of Software Design' FROM dual
            UNION ALL SELECT '18516367K', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '18516367K', 'Programación Orientada a Objetos con Java usando BlueJ' FROM dual
            UNION ALL SELECT '185196993', 'Power and Prediction: The Disruptive Economics of Artificial Intelligence' FROM dual
            UNION ALL SELECT '185219381', 'Aproximación a la Ingeniería del Software' FROM dual
            UNION ALL SELECT '185219381', 'Computer Science: An Overview - 12th Global Edition' FROM dual
            UNION ALL SELECT '185219381', 'Ingeniería de Software: Un Enfoque Práctico' FROM dual
            UNION ALL SELECT '18523691K', 'Power and Prediction: The Disruptive Economics of Artificial Intelligence' FROM dual
            UNION ALL SELECT '185254276', 'Erase Una Vez Un Algoritmo. Como Las Historias Explican La Computación' FROM dual
            UNION ALL SELECT '185279058', 'Arquitectura Limpia' FROM dual
            UNION ALL SELECT '18530561K', 'Ingeniería de Software: Un Enfoque Práctico' FROM dual
            UNION ALL SELECT '18530561K', 'Nier: Automata World Guide' FROM dual
            UNION ALL SELECT '18530561K', 'Python y Computación Paralela' FROM dual
            UNION ALL SELECT '18533069K', 'Automate The Boring Stuff with Python' FROM dual
            UNION ALL SELECT '18533069K', 'Estructuras de Datos en Java - 4ª Ed.' FROM dual
            UNION ALL SELECT '18533069K', 'Erase Una Vez Un Algoritmo. Como Las Historias Explican La Computación' FROM dual
            UNION ALL SELECT '185360505', 'El Imperio de la IA' FROM dual
            UNION ALL SELECT '185360505', 'Los Trucos de iPhone que Apple Nunca Te Contará' FROM dual
            UNION ALL SELECT '185394116', 'A Philosophy of Software Design' FROM dual
            UNION ALL SELECT '185394116', 'Computación al Minuto' FROM dual
            UNION ALL SELECT '185394116', 'Erase Una Vez Un Algoritmo. Como Las Historias Explican La Computación' FROM dual
            UNION ALL SELECT '185419925', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '185419925', 'Power and Prediction: The Disruptive Economics of Artificial Intelligence' FROM dual
            UNION ALL SELECT '185419925', 'Análisis y Diseño de Sistemas' FROM dual
            UNION ALL SELECT '185432794', 'Automate The Boring Stuff with Python' FROM dual
            UNION ALL SELECT '185447058', 'Programación Orientada a Objetos con Java usando BlueJ' FROM dual
            UNION ALL SELECT '185447058', 'El Imperio de la IA' FROM dual
            UNION ALL SELECT '18547361K', 'Arquitectura Limpia' FROM dual
            UNION ALL SELECT '185499554', 'Sombras de Raccoon City' FROM dual
            UNION ALL SELECT '185525105', 'Sombras de Raccoon City' FROM dual
            UNION ALL SELECT '185525105', 'El Imperio de la IA' FROM dual
            UNION ALL SELECT '185525105', 'Erase Una Vez Un Algoritmo. Como Las Historias Explican La Computación' FROM dual
            UNION ALL SELECT '185547036', 'Final Fantasy Ultimania Archive' FROM dual
            UNION ALL SELECT '185547036', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '185547036', 'Structure and Interpretation of Computer Programs - SICP' FROM dual
            UNION ALL SELECT '185565034', 'Ingeniería de Software: Un Enfoque Práctico' FROM dual
            UNION ALL SELECT '185565034', 'El Imperio de la IA' FROM dual
            UNION ALL SELECT '185594964', 'Sombras de Raccoon City' FROM dual
            UNION ALL SELECT '18562877K', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '185653057', 'Estructuras de Datos en Java - 4ª Ed.' FROM dual
            UNION ALL SELECT '185653057', 'Ingeniería de Software: Un Enfoque Práctico' FROM dual
            UNION ALL SELECT '185665365', 'Tecnología Digital Para Docentes. Computación y TIC' FROM dual
            UNION ALL SELECT '185679072', 'El Imperio de la IA' FROM dual
            UNION ALL SELECT '185702953', 'El Imperio de la IA' FROM dual
            UNION ALL SELECT '185702953', 'Programación Orientada a Objetos con Java usando BlueJ' FROM dual
            UNION ALL SELECT '185734391', 'Head First C' FROM dual
            UNION ALL SELECT '185734391', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '185751245', 'Ingeniería de Software: Un Enfoque Práctico' FROM dual
            UNION ALL SELECT '185751245', 'Final Fantasy Ultimania Archive' FROM dual
            UNION ALL SELECT '185751245', 'Tecnología Digital Para Docentes. Computación y TIC' FROM dual
            UNION ALL SELECT '185785239', 'Estructuras de Datos en Java - 4ª Ed.' FROM dual
            UNION ALL SELECT '185785239', 'Arquitectura Limpia' FROM dual
            UNION ALL SELECT '185785239', 'Clean Code Collection' FROM dual
            UNION ALL SELECT '185813771', 'Testeo y Verificación de Equipos y Periféricos Microinformáticos' FROM dual
            UNION ALL SELECT '185813771', 'Erase Una Vez Un Algoritmo. Como Las Historias Explican La Computación' FROM dual
            UNION ALL SELECT '185813771', 'Power and Prediction: The Disruptive Economics of Artificial Intelligence' FROM dual
            UNION ALL SELECT '185830439', 'Head First C' FROM dual
            UNION ALL SELECT '185843352', 'Aproximación a la Ingeniería del Software' FROM dual
            UNION ALL SELECT '185843352', 'Los Trucos de iPhone que Apple Nunca Te Contará' FROM dual
            UNION ALL SELECT '185843352', 'Erase Una Vez Un Algoritmo. Como Las Historias Explican La Computación' FROM dual
            UNION ALL SELECT '185860907', 'Los Trucos de iPhone que Apple Nunca Te Contará' FROM dual
            UNION ALL SELECT '185860907', 'Programación Orientada a Objetos con Java usando BlueJ' FROM dual
            UNION ALL SELECT '18588766K', 'Visual Studio 2010. Una Nueva Forma de Desarrollo' FROM dual
            UNION ALL SELECT '18588766K', 'Introducción a la Informática y al Uso y Manejo de Aplicaciones Comerciales' FROM dual
            UNION ALL SELECT '185920330', 'Visual Studio 2010. Una Nueva Forma de Desarrollo' FROM dual
            UNION ALL SELECT '185920330', 'Power and Prediction: The Disruptive Economics of Artificial Intelligence' FROM dual
            UNION ALL SELECT '185920330', 'Ingeniería de Software: Un Enfoque Práctico' FROM dual
            UNION ALL SELECT '185936024', 'Análisis y Diseño de Sistemas' FROM dual
            UNION ALL SELECT '185960952', 'Programación Orientada a Objetos con Java usando BlueJ' FROM dual
            UNION ALL SELECT '185989756', 'Final Fantasy Ultimania Archive' FROM dual
            UNION ALL SELECT '185989756', 'Ingeniería de Software: Un Enfoque Práctico' FROM dual
            UNION ALL SELECT '185989756', 'Instalación y Configuración de Periféricos Microinformáticos' FROM dual
            UNION ALL SELECT '18600088K', 'Automate The Boring Stuff with Python' FROM dual
            UNION ALL SELECT '18600088K', 'El Imperio de la IA' FROM dual
            UNION ALL SELECT '18600088K', 'Análisis y Diseño de Sistemas' FROM dual
            UNION ALL SELECT '18601919K', 'A Philosophy of Software Design' FROM dual
            UNION ALL SELECT '18601919K', 'Head First C' FROM dual
            UNION ALL SELECT '18601919K', 'Arquitectura Limpia' FROM dual
            UNION ALL SELECT '186050984', 'Power and Prediction: The Disruptive Economics of Artificial Intelligence' FROM dual
            UNION ALL SELECT '186050984', 'Instalación y Configuración de Periféricos Microinformáticos' FROM dual
            UNION ALL SELECT '186050984', 'Introducción a la Informática y al Uso y Manejo de Aplicaciones Comerciales' FROM dual
            UNION ALL SELECT '18606859K', 'Introducción a la Informática y al Uso y Manejo de Aplicaciones Comerciales' FROM dual
            UNION ALL SELECT '18606859K', 'Automate The Boring Stuff with Python' FROM dual
        ) asignaciones
        JOIN estudiantes persona
            ON REGEXP_REPLACE(UPPER(persona.rut), '[^0-9K]', '') = asignaciones.rut
        JOIN libros libro ON libro.titulo = asignaciones.titulo
    ) LOOP
        SELECT COUNT(*)
        INTO prestamos_existentes
        FROM prestamos
        WHERE id_estudiante = (
                  SELECT id FROM estudiantes
                  WHERE REGEXP_REPLACE(UPPER(rut), '[^0-9K]', '') = asignacion.rut
              )
          AND id_libro = (
                  SELECT id FROM libros WHERE titulo = asignacion.titulo
              );

        IF prestamos_existentes = 0 THEN
            UPDATE libros
            SET stock = stock - 1
            WHERE titulo = asignacion.titulo
              AND stock > 0;

            IF SQL%ROWCOUNT = 0 THEN
                RAISE_APPLICATION_ERROR(-20001,
                    'No hay stock disponible para: ' || asignacion.titulo);
            END IF;

            INSERT INTO prestamos (id_estudiante, id_libro, fecha_prestamo, devuelto)
            VALUES (
                (SELECT id FROM estudiantes
                 WHERE REGEXP_REPLACE(UPPER(rut), '[^0-9K]', '') = asignacion.rut),
                (SELECT id FROM libros WHERE titulo = asignacion.titulo),
                SYSDATE,
                0
            );
        END IF;
    END LOOP;

    COMMIT;
END;
/
