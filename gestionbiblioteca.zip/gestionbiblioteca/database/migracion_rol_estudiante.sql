-- Ejecutar una vez en el esquema de la aplicación si estudiantes ya existe
-- sin la columna ROL.
DECLARE
    columna_existe NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO columna_existe
    FROM user_tab_columns
    WHERE table_name = 'ESTUDIANTES'
      AND column_name = 'ROL';

    IF columna_existe = 0 THEN
        EXECUTE IMMEDIATE
            'ALTER TABLE estudiantes ADD (rol VARCHAR2(60) DEFAULT ''Estudiante'' NOT NULL)';
    END IF;
END;
/
